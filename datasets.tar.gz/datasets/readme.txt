Contiene los datasets definitivos:

* Jazz: ficheros midi de jazz

* Kar: ficheros midi de musica moderna/pop/rock/folk

* Class: ficheros de musica clásica

* arff: 
	arff files for each dataset
	model files created using the command: java -cp weka.jar weka.classifiers.trees.RandomForest -K 6 -I 10 -t file.arff -d file.model

2015-07-21: piano and normal datasets created
2015-08-06: created arff files. Some issues fixed in class.csv
2015-08-18: added accomp tar in csv files
2015-08-24: created arff/model files for accomp
2015-10-24: created arff/model files again
